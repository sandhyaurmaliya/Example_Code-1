var producten = [
    { naam: "The Bastard Small", prijs: 269 , promo: 219, beeld: "https://image.coolblue.be/max/500x500/products/1367641"},
    { naam: "Barbecook Loewy 40", prijs: 79.99 , promo: 0, beeld:"https://image.coolblue.be/max/500x500/products/1374308"},
    { naam: "RedFire vuurschaal BBGrill Orion Classic Rust", prijs: 999 , promo: 500, beeld: "https://static.dreamland.be/wcsstore/ColruytB2CCAS/JPG/JPG/646x1000/std.lang.all/01/10/asset-1660110.jpg"},
    { naam: "Outsunny Houtskoolgrill BBQ", prijs: 146.99, promo: 0, beeld:"https://l-westfalia-eu.secure.footprint.net/medien/scaled_pix/1200/1200/000/000/000/000/066/923/72.jpg"},
    { naam: "Boretti Barbecue Barilo", prijs: 347.35 , promo: 0, beeld:"https://img.artencraft.be/i/3189128.jpg"},
    { naam: "Weber Master Touch GBS C-5750 Grijs", prijs: 279 , promo: 0, beeld:"https://image.coolblue.be/max/2048x1536/products/1408500"}
   ];

function getimage()
{
    var index;
    var name ="";

    for(index=0; index<producten.length; index++)
    {  
               

        if(producten[index].promo!=0)
        {
            document.getElementById("beelden").innerHTML +=  '<section id="product'+index+'"><img  src=" '+producten[index].beeld+'"alt= " '
                +producten[index].naam+'">' + "<p>" + producten[index].naam + "</p>" + 
                "<p>" +"<s>" + "€" + producten[index].prijs + "</s>" + "</p>" + "<p style='color: red;'>" +"€"+ producten[index].promo +"</p>"
                       +'<button id="plus" value="plus" onclick="plusmin('+index+', id)">+</button>'   + 
                   '<button id="minus" value="minus" onclick="plusmin('+index+', id)">-</button>' +"</section>" +
                    "<br/>";                 
         }               
               
        else
        {
            document.getElementById("beelden").innerHTML +=  
               '<section id="product'+index+'"><img  src=" '+producten[index].beeld+'" alt= " '+producten[index].naam+'">'+
               "<p>" + producten[index].naam + "</p>" +
               "<p>" + "€" + producten[index].prijs + "</p>" +
               '<button id="plus" value="plus" onclick="plusmin('+index+', id)">+</button>'  +
               '<button id="minus" value="minus" onclick="plusmin('+index+', id)">-</button>'+ "</section>"+
               "<br/>"; 
        }
    }
}


function getvalue()
{
    var index;
    var name ="";

    for(index=0; index<producten.length; index++)
    {                

        if(producten[index].promo!=0)
        {
            producten[index].prijs = producten[index].promo;
        }
                
        document.getElementById("producten").innerHTML += "<p>"+ "<b>"+producten[index].naam+"</b>" + "</p>"+  "<p>"+": €" + producten[index].prijs.toFixed(2) + "</p>"+
            "<p>"+'<input type="text" id= "'+index+'" value="0"></input>' +  
              
               
               '<button id="plus" value="plus" onclick="plusmin('+index+', id)">+</button>'   +
               '<button id="minus" value="minus" onclick="plusmin('+index+', id)">-</button>'+
                 "</p>"+"<br/>";   

    }
}

function plusmin(id, plusmin_id) 
    {  
        
        var aantal = document.getElementById(id).value; 
        
        if (plusmin_id == "plus")
            {
                aantal++;
                document.getElementById(id).value= aantal;
            }

            else if (aantal >= 1)
            {
                aantal--;
                document.getElementById(id).value= aantal;
            } 
        gettotaal()
    }
  

  function gettotaal()
  {
    var totaal = 0;

    var aantal;
    
 
 
  for ( index = 0; index < producten.length ; index++ )
    { 
        

        aantal = Number(document.getElementById(index).value);  
        
        if(producten[index].promo!=0)
        {
            producten[index].prijs = producten[index].promo;
        }
        totaal += aantal * producten[index].prijs;
    }
        
        
    
     
    document.getElementById("totaal").innerHTML = "€"+ +totaal.toFixed(2);
 
    var land = document.getElementById("land").value;
        
        var leveringkost = berekenTransportKost(land, totaal); 
        var totaal_excl_btw = 0;
        var btw = 0;
        var totaal_incl_btw = 0;

        if (leveringkost == 0)
            {
                leveringkost = "Gratis";
                document.getElementById("levering").innerHTML = leveringkost;
                totaal_excl_btw = totaal
            } 
        else
            {
            document.getElementById("levering").innerHTML = "€  "+ leveringkost;

            totaal_excl_btw = totaal + leveringkost;
            }

        document.getElementById("total_excl_btw").innerHTML = "€"+ totaal_excl_btw.toFixed(2);

        btw = totaal_excl_btw * 0.21; 

        document.getElementById("btw").innerHTML = "€"+ btw.toFixed(2);

        totaal_incl_btw = totaal_excl_btw + btw;
        document.getElementById("total_inc_btw").innerHTML = "€"+ totaal_incl_btw.toFixed(2);
    
}


function berekenTransportKost(land, totaal) 
    {
        
        var levering = 0;
        if (land == "België" && totaal < 30)
            {
                levering = 10;                 
            }
            else if (land == "België")
                {
                    levering = 0;
                }

        if (land == "Nederland" && totaal < 50)
            {
                levering = 13;
            }
            else if (land == "Nederland")
                {
                    levering = 0;
                }
        
        if (land == "Luxemberg" && totaal < 50)
            {
                levering = 13;
            }
            else if (land == "Luxemberg")
                {
                    levering = 0;
                }
        
        if (land == "Frankrijk" && totaal < 70)
            {
                levering = 15;
            }
            else if (land == "Frankrijk")
                {
                    levering = 0;
                }
            
        if (land == "Duitsland" && totaal < 70)
            {
                levering = 15;
            }
            else if (land == "Duitsland")
                {
                    levering = 0;
                }
        return levering;
    }